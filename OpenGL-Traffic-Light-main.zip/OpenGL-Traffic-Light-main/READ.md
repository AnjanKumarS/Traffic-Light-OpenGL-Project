This is a C++ project made using OpenGL to demostrate Traffic Light.

Light works using arrow keys
LEFT ARROW : green light
RIGHT ARROW : yellow light
UP ARROW : red light
DOWN ARROW : no lights
